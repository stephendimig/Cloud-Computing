/**********************************
 * FILE NAME: MP1Node.cpp
 *
 * DESCRIPTION: Membership protocol run by this Node.
 * 				Header file of MP1Node class.
 **********************************/

#ifndef _MP1NODE_H_
#define _MP1NODE_H_

#include "stdincludes.h"
#include "Log.h"
#include "Params.h"
#include "Member.h"
#include "EmulNet.h"
#include "Queue.h"

/**
 * Macros
 */
#define TREMOVE 20
#define TFAIL 5

/*
 * Note: You can change/add any functions in MP1Node.{h,cpp}
 */

/**
 * Message Types
 */
enum MsgTypes
{
    JOINREQ = 1,
    JOINREP,
    HEARTBEATREQ,
    HEARTBEATREP,
    GOSSIP,
    GOSSIPREP,
    DUMMYLASTMSGTYPE
};

/**
 * STRUCT NAME: MessageHdr
 *
 * DESCRIPTION: Header and content of a message
 */
typedef struct MessageHdr 
{
    enum MsgTypes msgType;
}MessageHdr;


class JoinResponseMessage;
class JoinRequestMessage;
class HeartbeatResponseMessage;
class HeartbeatRequestMessage;
class GossipMessage;
class GossipResponseMessage;

class MessageInterface
{
public:
    virtual ~MessageInterface() {}
    virtual bool recvJoinResponseMessage(JoinResponseMessage & rMessage) { return false; }
    virtual bool recvJoinRequestMessage(JoinRequestMessage & rMessage) { return false; }
    virtual bool recvHeartbeatResponseMessage(HeartbeatResponseMessage & rMessage) { return false; }
    virtual bool recvHeartbeatRequestMessage(HeartbeatRequestMessage & rMessage) { return false; }
    virtual bool recvGossipMessage(GossipMessage & rMessage) { return false; }
    virtual bool recvGossipResponseMessage(GossipResponseMessage & rMessage) { return false; }
};


class Message
{
public:
    struct Data
    {
        enum MsgTypes _msgType;
        char _addr[6];
        short _pad;
        long _heartbeat;
    } __attribute__ ((packed));


    Message(void) {}
    virtual ~Message(void) {}

    virtual int size(void) const
    {
        return sizeof(_data);
    }

    virtual char * serialize(void)
    {
        return (char *)&_data;
    }

    virtual Address addr(void) const
    {
        Address address;
        memcpy(address.addr, _data._addr, sizeof(address.addr));
        return address;
    }

    virtual int id(void) const
    {
        int id;
        memcpy(&id, _data._addr, sizeof(int));
        return id;
    }

    virtual short port(void) const
    {
        short port;
        memcpy(&port, &_data._addr[4], sizeof(short));
        return port;
    }

    static int id(Address address)
    {
        int id;
        memcpy(&id, &address.addr[0], sizeof(int));
        return id;
    }

    static short port(Address address)
    {
        short port;
        memcpy(&port, &address.addr[4], sizeof(short));
        return port;
    }

    static Address addr(int id, short port)
    {
        Address address;
        memcpy(address.addr, &id, sizeof(id));
        memcpy(&address.addr[4], &port, sizeof(port));
        return address;
    }


    virtual bool deserialize(char * pData, size_t len)
    {
        bool retval = false;
        if(sizeof(Data) == len)
        {
            retval = true;
            memcpy(&_data, pData, len);
        }
        return retval;
    }


    virtual MsgTypes type() const
    {
        return _data._msgType;
    }


    virtual long heartbeat() const
    {
        return _data._heartbeat;
    }

    virtual void prettyprint(ostream & os) const = 0;
    virtual bool visit(MessageInterface & intf) { return false; }

    const char * msgTypeDescription() const
    {
        return Descriptions[type()];
    }
    
    friend ostream &operator<<(ostream & os, const Message & rMessage)     
    {
        rMessage.prettyprint(os);
        return os;
    }
protected:
    Data _data;
    static const char * Descriptions[];
};


class MessageFactory
{
public:
    static Message * create(char * pData, size_t len);
};


class JoinRequestMessage : public Message
{
public:
    JoinRequestMessage(char * addr, long heartbeat)
        {
            _data._msgType = JOINREQ;
            _data._heartbeat = heartbeat;
            memcpy(_data._addr, addr, sizeof(_data._addr));
        }
        
    JoinRequestMessage(void)
    {
    }

    virtual ~JoinRequestMessage(void) {}

    void prettyprint(ostream & os) const
    {
        os << "MsgType=" << msgTypeDescription() << "; heartbeat=" << _data._heartbeat << ends;
    }

    bool visit(MessageInterface & intf) 
    {
        return intf.recvJoinRequestMessage(*this);
    }

private:
};


class JoinResponseMessage  : public Message
{
public:
    JoinResponseMessage(char * addr, long heartbeat)
        {
            _data._msgType = JOINREP;
            _data._heartbeat = heartbeat;
            memcpy(_data._addr, addr, sizeof(_data._addr));
        }
        
    JoinResponseMessage(void) {}

    virtual ~JoinResponseMessage(void) {}

    void prettyprint(ostream & os) const
    {
        os << "MsgType=" << msgTypeDescription() << "; heartbeat=" << _data._heartbeat << ends;
    }

    bool visit(MessageInterface & intf) 
    {
        return intf.recvJoinResponseMessage(*this);
    }

private:
};


class HeartbeatRequestMessage : public Message
{
public:
    HeartbeatRequestMessage(int id, short port, long heartbeat)
    {
        _data._msgType = HEARTBEATREQ;
        _data._heartbeat = heartbeat;
        memcpy(_data._addr, &id, sizeof(id));
        memcpy(&_data._addr[4], &port, sizeof(port));
    }
    
    HeartbeatRequestMessage(void)
    {
    }

    virtual ~HeartbeatRequestMessage(void) {}

    void prettyprint(ostream & os) const
    {
        os << "MsgType=" << msgTypeDescription() << "; heartbeat=" << _data._heartbeat << ends;
    }

    bool visit(MessageInterface & intf) 
    {
        return intf.recvHeartbeatRequestMessage(*this);
    }

private:
};


class HeartbeatResponseMessage : public Message
{
public:
    HeartbeatResponseMessage(char * addr, long heartbeat)
    {
        _data._msgType = HEARTBEATREP;
        _data._heartbeat = heartbeat;
        strncpy(_data._addr, addr, sizeof(_data._addr));
    }
    
    HeartbeatResponseMessage(void)
    {
    }

    virtual ~HeartbeatResponseMessage(void) {}

    void prettyprint(ostream & os) const
    {
        os << "MsgType=" << msgTypeDescription() << "; heartbeat=" << _data._heartbeat << ends;
    }

    bool visit(MessageInterface & intf) 
    {
        return intf.recvHeartbeatResponseMessage(*this);
    }

private:
};



class GossipResponseMessage : public Message
{
public:
    GossipResponseMessage(char * addr, long heartbeat)
    {
        _data._msgType = HEARTBEATREP;
        _data._heartbeat = heartbeat;
        strncpy(_data._addr, addr, sizeof(_data._addr));
    }
    
    GossipResponseMessage(void)
    {
    }

    virtual ~GossipResponseMessage(void) {}

    void prettyprint(ostream & os) const
    {
        os << "MsgType=" << msgTypeDescription() << "; heartbeat=" << _data._heartbeat << ends;
    }

    bool visit(MessageInterface & intf) 
    {
        return intf.recvGossipResponseMessage(*this);
    }

private:
};


class GossipMessage : public Message
{
public:
    static const int MAXIMUM_MEMBER_LIST_ENTRIES = 50;
    struct Data
    {
        enum MsgTypes _msgType;
        char _addr[6];
        short _pad;
        long _numberEntries;
        int _ids[MAXIMUM_MEMBER_LIST_ENTRIES];
        short _ports[MAXIMUM_MEMBER_LIST_ENTRIES];
        long _heartbeats[MAXIMUM_MEMBER_LIST_ENTRIES];
        long _timestamps[MAXIMUM_MEMBER_LIST_ENTRIES];;
        
    } __attribute__ ((packed));


    GossipMessage(int id, short port, Member * pMember, vector<MemberListEntry> & memberList, Params * par)
    {
         long now = par->getcurrtime();

        _data._numberEntries = 0;
        _data._msgType = GOSSIP;
        memcpy(_data._addr, &id, sizeof(id));
        memcpy(&_data._addr[4], &port, sizeof(port));

        vector<MemberListEntry>::iterator iter = memberList.begin();
        
        for(; iter != memberList.end() && _data._numberEntries <= MAXIMUM_MEMBER_LIST_ENTRIES; ++iter)
        {
            long ts = iter->gettimestamp();
            long diff = now - ts;
            if(-1 == ts || diff <  TFAIL)
            {
                _data._ids[_data._numberEntries] = iter->getid();
                _data._ports[_data._numberEntries] = iter->getport();
                _data._heartbeats[_data._numberEntries] = iter->getheartbeat();
                _data._timestamps[_data._numberEntries] = iter->gettimestamp();
                _data._numberEntries++;
            }

        }
        // Add self to list
        if(NULL != pMember && _data._numberEntries <= MAXIMUM_MEMBER_LIST_ENTRIES)
        {
            _data._ids[_data._numberEntries] = Message::id(pMember->addr);
            _data._ports[_data._numberEntries] = Message::port(pMember->addr);
            _data._heartbeats[_data._numberEntries] = pMember->heartbeat;
            _data._timestamps[_data._numberEntries] = par->getcurrtime();
            _data._numberEntries++;
        }
    }

    GossipMessage(void) {}

    virtual ~GossipMessage(void) {}

    int size(void) const
    {
        return sizeof(_data);
    }

    char * serialize(void)
    {
        return (char *)&_data;
    }

    Address addr(void) const
    {
        Address address;
        memcpy(address.addr, _data._addr, sizeof(address.addr));
        return address;
    }
    
    int id(void) const
    {
        int id;
        memcpy(&id, _data._addr, sizeof(int));
        return id;
    }

    short port(void) const
    {
        short port;
        memcpy(&port, &_data._addr[4], sizeof(short));
        return port;
    }

    long numberEntries() const
    {
        return _data._numberEntries;
    }

    int idAt(int index) const
    {
        int retval = 0;
        if(index < _data._numberEntries)
        {
            retval = _data._ids[index];
        }
        return retval;
    }

    short portAt(int index) const
    {
        short retval = 0;
        if(index < _data._numberEntries)
        {
            retval = _data._ports[index];
        }
        return retval;
    }

    long heartbeatAt(int index) const
    {
        long retval = 0;
        if(index < _data._numberEntries)
        {
            retval = _data._heartbeats[index];
        }
        return retval;
    }

    long timestampAt(int index) const
    {
        long retval = 0;
        if(index < _data._numberEntries)
        {
            retval = _data._timestamps[index];
        }
        return retval;
    }

    virtual bool deserialize(char * pData, size_t len)
    {
        bool retval = false;
        if(sizeof(Data) == len)
        {
            retval = true;
            memcpy(&_data, pData, len);
        }
        return retval;
    }


    MsgTypes type() const
    {
        return _data._msgType;
    }

    void prettyprint(ostream & os) const
    {
         os << "MsgType=" << msgTypeDescription() << "; numberEntries=" << _data._numberEntries << "; ids<";
         for(int i = 0; i < _data._numberEntries; ++i)
         {
             os << _data._ids[i] << ",";
         }
         os << ">; ports<";
         for(int i = 0; i < _data._numberEntries; ++i)
         {
             os << _data._ports[i] << ",";
         }
         os << ">; heartbeats<";
         for(int i = 0; i < _data._numberEntries; ++i)
         {
             os << _data._heartbeats[i] << ",";
         }
         os << ">; timestamps<";
         for(int i = 0; i < _data._numberEntries; ++i)
         {
             os << _data._timestamps[i] << ",";
         }
         os << ">" << ends;
    }

    bool visit(MessageInterface & intf) 
    {
        return intf.recvGossipMessage(*this);
    }
    

protected:
    Data _data;
    static const char * Descriptions[];
};



/**
 * CLASS NAME: MP1Node
 *
 * DESCRIPTION: Class implementing Membership protocol functionalities for failure detection
 */
class MP1Node : public MessageInterface
{
private:
    EmulNet *emulNet;
    Log *log;
    Params *par;
    Member *memberNode;
    char NULLADDR[6];
    bool isShutdown;
public:
    MP1Node(Member *, Params *, EmulNet *, Log *, Address *);
    Member * getMemberNode() 
    {
        return memberNode;
    }
    
    int recvLoop();
    static int enqueueWrapper(void *env, char *buff, int size);
    void nodeStart(char *servaddrstr, short serverport);
    int initThisNode(Address *joinaddr);
    int introduceSelfToGroup(Address *joinAddress);
    int finishUpThisNode();
    void nodeLoop();
    void checkMessages();
    bool recvCallBack(void *env, char *data, int size);
    void nodeLoopOps();
    int isNullAddress(Address *addr);
    Address getJoinAddress();

    void initMemberListTable(Member *memberNode);
    MemberListEntry * findMemberListTable(int id, short port);
    void insertMemberListTable(int id, short port, long heartbeat);
    void removeMemberListTable(vector<MemberListEntry> list);
    void mergeMemberListTable(GossipMessage & rMessage);

    void printAddress(Address *addr);
    ostream & printAddress(Address *addr, ostream & os);
    virtual ~MP1Node();

    // Methods overridden from MessageInterface
    bool recvJoinResponseMessage(JoinResponseMessage & rMessage);
    bool recvJoinRequestMessage(JoinRequestMessage & rMessage);
    bool recvHeartbeatResponseMessage(HeartbeatResponseMessage & rMessage);
    bool recvHeartbeatRequestMessage(HeartbeatRequestMessage & rMessage);
    bool recvGossipMessage(GossipMessage & rMessage);
    bool recvGossipResponseMessage(GossipResponseMessage & rMessage);
};

#endif /* _MP1NODE_H_ */
